// 1. Arithmetic
function calculate() {
    let a = Number(document.getElementById("num1").value);
    let b = Number(document.getElementById("num2").value);
    let op = document.querySelector("input[name='op']:checked");

    if (!op) {
        alert("Select an operator");
        return;
    }

    let result;

    if (op.value === "+") result = a + b;
    if (op.value === "-") result = a - b;
    if (op.value === "*") result = a * b;
    if (op.value === "/") {
        if (b === 0) {
            alert("Cannot divide by zero");
            return;
        }
        result = a / b;
    }

    alert("Result: " + result);
}

// 2. Factorial
function factorial() {
    let n = Number(document.getElementById("factInput").value);
    let result = 1;

    for (let i = 1; i <= n; i++) {
        result *= i;
    }

    alert("Factorial: " + result);
}

// 3. Fibonacci
function fib() {
    let n = Number(document.getElementById("fibInput").value);

    let a = 0, b = 1, temp;

    for (let i = 2; i <= n; i++) {
        temp = a + b;
        a = b;
        b = temp;
    }

    alert("Fibonacci: " + (n === 0 ? 0 : b));
}

// 4. Min / Max / Range
function minMax() {
    let a = Number(document.getElementById("a").value);
    let b = Number(document.getElementById("b").value);
    let c = Number(document.getElementById("c").value);

    let max = Math.max(a, b, c);
    let min = Math.min(a, b, c);
    let range = max - min;

    alert("Max: " + max + "\nMin: " + min + "\nRange: " + range);
}

// 5. Mailing List
function addUser() {
    let first = document.getElementById("first").value;
    let last = document.getElementById("last").value;
    let email = document.getElementById("email").value;
    let zip = document.getElementById("zip").value;

    let output = first + " " + last + " | " + email + " | " + zip + "<br>";

    document.getElementById("outputList").innerHTML += output;
}

function resetForm() {
    document.getElementById("first").value = "";
    document.getElementById("last").value = "";
    document.getElementById("email").value = "";
    document.getElementById("zip").value = "";
}